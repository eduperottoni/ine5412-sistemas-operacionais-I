#include "cpu.h"
#include <iostream>
#include "main_class.h"

__USING_API 


int main(void)
{

    Main::run();

    return 0;
}
