#include "window.h"

int main(void)
{
    Window window;

    window.run();

    return 0;
}
